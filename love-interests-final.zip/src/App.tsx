import './App.css'
import { useEffect, useMemo, useState } from 'react'
import { api } from './api/api'
import { decryptJson, encryptJson } from './crypto/aead'
import { derivePairAesKey } from './crypto/sharedKey'
import { exportBackup, importBackup, loadIdentity, type Identity } from './state/identity'
import { QrInvite, QrScanner } from './ui/qr'
import type { AnswerChoice, DecryptedQuestion, PairView, QuestionView } from './types'

function App() {
  const [identity, setIdentity] = useState<Identity | null>(null)
  const [nickname, setNickname] = useState('')
  const [pair, setPair] = useState<PairView | null>(null)
  const [pairIdInput, setPairIdInput] = useState('')
  const [qrScanOpen, setQrScanOpen] = useState(false)
  const [questionText, setQuestionText] = useState('')
  const [questions, setQuestions] = useState<DecryptedQuestion[]>([])
  const [rawQuestions, setRawQuestions] = useState<QuestionView[]>([])
  const [matchesJson, setMatchesJson] = useState('')
  const [weeklyLimitInput, setWeeklyLimitInput] = useState('5')
  const [error, setError] = useState<string | null>(null)

  const apiReady = !!identity?.userId
  const apiClient = useMemo(() => {
    if (!identity?.userId) return null
    return api({
      baseUrl: import.meta.env.VITE_API_BASE ?? 'http://localhost:3001',
      getAuthMaterial: async () => identity.auth,
    })
  }, [identity])

  useEffect(() => {
    ;(async () => {
      const id = await loadIdentity()
      setIdentity(id)
      setNickname(id?.nickname ?? '')
    })()
  }, [])

  async function register() {
    try {
      setError(null)
      const next = await loadIdentity({ nickname: nickname.trim() || 'Anon', ensureRegistered: true })
      if (!next) throw new Error('identity_not_available')
      setIdentity(next)
      setNickname(next.nickname)
    } catch (e: any) {
      setError(e?.message ?? String(e))
    }
  }

  async function refreshPair(pairId: string) {
    if (!apiClient) return
    const p = await apiClient.pair.get(pairId)
    setPair(p)
    setWeeklyLimitInput(String(p.weeklyLimit))
  }

  async function createPair() {
    if (!apiClient) return
    setError(null)
    const { pairId } = await apiClient.pair.create()
    await refreshPair(pairId)
  }

  async function joinPair(pairId: string) {
    if (!apiClient) return
    setError(null)
    await apiClient.pair.join(pairId)
    await refreshPair(pairId)
  }

  async function confirmPair(pairId: string) {
    if (!apiClient) return
    setError(null)
    await apiClient.pair.confirm(pairId)
    await refreshPair(pairId)
  }

  async function proposeWeeklyLimit() {
    if (!apiClient || !pair) return
    const limit = Number(weeklyLimitInput)
    if (!Number.isFinite(limit)) return
    await apiClient.pair.proposeWeeklyLimit(pair.id, limit)
    await refreshPair(pair.id)
  }

  async function loadQuestionsAndDecrypt() {
    if (!apiClient || !pair || !identity) return
    setError(null)
    const list = await apiClient.questions.list(pair.id)
    setRawQuestions(list)

    const aes = await derivePairAesKey(identity.keys.ecdhPrivateKey, pair, identity.userId!)
    const decoded: DecryptedQuestion[] = []
    for (const q of list) {
      try {
        const payload = await decryptJson<{ text: string }>(aes, q.blob)
        decoded.push({ ...q, text: payload.text })
      } catch {
        decoded.push({ ...q, text: '[Entschlüsselung fehlgeschlagen]' })
      }
    }
    setQuestions(decoded.sort((a, b) => b.createdAt - a.createdAt))
  }

  async function addQuestion() {
    if (!apiClient || !pair || !identity) return
    setError(null)
    const text = questionText.trim()
    if (!text) return
    const aes = await derivePairAesKey(identity.keys.ecdhPrivateKey, pair, identity.userId!)
    const blob = await encryptJson(aes, { text }, `love-interests|pair:${pair.id}|question`)
    await apiClient.questions.create(pair.id, blob)
    setQuestionText('')
    await loadQuestionsAndDecrypt()
  }

  async function answer(questionId: string, choice: AnswerChoice) {
    if (!apiClient || !pair || !identity) return
    setError(null)
    const aes = await derivePairAesKey(identity.keys.ecdhPrivateKey, pair, identity.userId!)
    const blob = await encryptJson(aes, { answer: choice }, `love-interests|pair:${pair.id}|answer|q:${questionId}`)
    await apiClient.answers.create(questionId, blob)
    await loadQuestionsAndDecrypt()
  }

  async function computeMatches() {
    if (!apiClient || !pair || !identity) return
    setError(null)
    const aes = await derivePairAesKey(identity.keys.ecdhPrivateKey, pair, identity.userId!)
    const matches: any[] = []
    for (const q of rawQuestions) {
      const answers = await apiClient.answers.list(q.id)
      const decoded: AnswerChoice[] = []
      for (const a of answers) {
        try {
          const payload = await decryptJson<{ answer: AnswerChoice }>(aes, a.blob)
          decoded.push(payload.answer)
        } catch {
          decoded.push('maybe')
        }
      }
      if (decoded.length < 2) continue
      if (!decoded.includes('no')) {
        const questionText = questions.find((x) => x.id === q.id)?.text ?? '[?]'
        matches.push({ question: questionText, answers: decoded })
      }
    }
    setMatchesJson(JSON.stringify(matches, null, 2))
  }

  async function doExportBackup() {
    const txt = await exportBackup()
    await navigator.clipboard.writeText(txt)
    alert('Backup (JSON) wurde in die Zwischenablage kopiert.')
  }

  async function doImportBackup() {
    const txt = prompt('Backup JSON einfügen:')
    if (!txt) return
    await importBackup(txt)
    const id = await loadIdentity()
    setIdentity(id)
    setNickname(id?.nickname ?? '')
    alert('Import abgeschlossen.')
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="logo">LI</div>
          <div>
            <div className="title">love.interests</div>
            <div className="subtitle">E2E Fragen-Spiel für Paare</div>
          </div>
        </div>
        <div className="top-actions">
          <button className="secondary" onClick={doExportBackup}>
            Backup kopieren
          </button>
          <button className="secondary" onClick={doImportBackup}>
            Backup importieren
          </button>
        </div>
      </header>

      <main className="grid">
        <section className="card">
          <h2>1) Account</h2>
          <p className="hint">
            Ohne E-Mail/Passwort. Dein Gerät hält die privaten Schlüssel. Backup
            ist wichtig.
          </p>
          <label className="field">
            <span>Nickname</span>
            <input value={nickname} onChange={(e) => setNickname(e.target.value)} />
          </label>
          <div className="row">
            <button onClick={register}>Account erstellen / laden</button>
            <span className="mono">
              {identity?.userId ? `userId: ${identity.userId}` : 'nicht registriert'}
            </span>
          </div>
        </section>

        <section className="card">
          <h2>2) Pairing</h2>
          <p className="hint">
            Pairing-Code im QR, Join über Scan oder manuell. Danach beide
            bestätigen.
          </p>
          <div className="row">
            <button onClick={createPair} disabled={!apiReady}>
              Pair erstellen
            </button>
            <button className="secondary" onClick={() => setQrScanOpen(true)} disabled={!apiReady}>
              QR scannen
            </button>
          </div>

          {pair?.id ? (
            <div className="pair-box">
              <div className="row">
                <div>
                  <div className="pair-label">Pair-ID</div>
                  <div className="pair-id mono">{pair.id}</div>
                </div>
                <div className="pill">{pair.status}</div>
              </div>
              <QrInvite value={JSON.stringify({ pairId: pair.id })} />
              <div className="row">
                <button onClick={() => confirmPair(pair.id)} disabled={!apiReady}>
                  Bestätigen
                </button>
                <button className="secondary" onClick={() => refreshPair(pair.id)} disabled={!apiReady}>
                  Sync
                </button>
              </div>

              <div className="two-col">
                <div>
                  <div className="pair-label">Du</div>
                  <div className="mono">{pair.me.nickname}</div>
                </div>
                <div>
                  <div className="pair-label">Partner</div>
                  <div className="mono">{pair.partner ? pair.partner.nickname : '—'}</div>
                </div>
              </div>

              <div className="divider" />
              <div className="row">
                <label className="field inline">
                  <span>Wochenlimit</span>
                  <input value={weeklyLimitInput} onChange={(e) => setWeeklyLimitInput(e.target.value)} />
                </label>
                <button className="secondary" onClick={proposeWeeklyLimit} disabled={!apiReady}>
                  Vorschlagen
                </button>
              </div>
              <p className="hint">
                Aktiv, sobald beide Partner denselben Wert vorschlagen.
              </p>
            </div>
          ) : (
            <div className="pair-box">
              <label className="field">
                <span>Pair-ID manuell</span>
                <input value={pairIdInput} onChange={(e) => setPairIdInput(e.target.value)} placeholder="z.B. ab12cd34" />
              </label>
              <div className="row">
                <button onClick={() => joinPair(pairIdInput.trim())} disabled={!apiReady}>
                  Join
                </button>
                <button className="secondary" onClick={() => refreshPair(pairIdInput.trim())} disabled={!apiReady}>
                  Laden
                </button>
              </div>
            </div>
          )}
        </section>

        <section className="card wide">
          <h2>3) Fragen (verschlüsselt)</h2>
          <p className="hint">
            Der Server speichert nur Ciphertext. Entschlüsselung passiert nur
            bei dir und deinem Partner.
          </p>
          <div className="row">
            <input
              className="grow"
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              placeholder="z.B. Möchtest du mal ein Rollenspiel ausprobieren?"
              disabled={!pair || pair.status !== 'active'}
            />
            <button onClick={addQuestion} disabled={!pair || pair.status !== 'active'}>
              Frage stellen
            </button>
            <button className="secondary" onClick={loadQuestionsAndDecrypt} disabled={!pair}>
              Aktualisieren
            </button>
          </div>

          <div className="question-list">
            {questions.map((q) => (
              <div className="question" key={q.id}>
                <div className="q-meta">
                  <span className="mono">{new Date(q.createdAt).toLocaleString()}</span>
                  <span className="mono">von {q.createdBy === identity?.userId ? 'dir' : 'Partner'}</span>
                </div>
                <div className="q-text">{q.text}</div>
                <div className="row">
                  <button className="choice" onClick={() => answer(q.id, 'yes')} disabled={!pair || pair.status !== 'active'}>
                    Ja
                  </button>
                  <button className="choice secondary" onClick={() => answer(q.id, 'maybe')} disabled={!pair || pair.status !== 'active'}>
                    Vielleicht
                  </button>
                  <button className="choice danger" onClick={() => answer(q.id, 'no')} disabled={!pair || pair.status !== 'active'}>
                    Nein
                  </button>
                </div>
              </div>
            ))}
            {pair && questions.length === 0 ? <div className="empty">Noch keine Fragen.</div> : null}
          </div>

          <div className="divider" />
          <div className="row">
            <button className="secondary" onClick={computeMatches} disabled={!pair}>
              Matches auswerten
            </button>
            <span className="hint">Nur wenn keiner „Nein“ gesagt hat.</span>
          </div>
          {matchesJson ? <pre className="pre">{matchesJson}</pre> : null}
        </section>

        {qrScanOpen ? (
          <div className="modal">
            <div className="modal-body card">
              <div className="row">
                <h2>QR Scan</h2>
                <button className="secondary" onClick={() => setQrScanOpen(false)}>
                  Schließen
                </button>
              </div>
              <QrScanner
                onValue={async (text) => {
                  try {
                    const obj = JSON.parse(text)
                    const pairId = String(obj?.pairId ?? '')
                    if (!pairId) throw new Error('QR ohne pairId')
                    await joinPair(pairId)
                    setQrScanOpen(false)
                  } catch (e: any) {
                    setError(e?.message ?? String(e))
                  }
                }}
              />
              <p className="hint">
                Browser ohne QR-Support? Dann nutze die manuelle Pair-ID.
              </p>
            </div>
          </div>
        ) : null}

        {error ? (
          <section className="card error">
            <h2>Fehler</h2>
            <pre className="pre">{error}</pre>
          </section>
        ) : null}
      </main>
    </div>
  )
}

export default App

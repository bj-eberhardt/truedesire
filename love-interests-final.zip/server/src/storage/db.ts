import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { FileStore } from './fileStore.js'

export type UserRecord = {
  id: string
  nickname: string
  signPublicJwk: JsonWebKey
  ecdhPublicRawB64: string
  createdAt: number
}

export type PairRecord = {
  id: string
  userA: string
  userB: string | null
  confirmA: boolean
  confirmB: boolean
  status: 'pending' | 'active'
  weeklyLimit: number
  weeklyLimitProposals: { [userId: string]: number | undefined }
  createdAt: number
  updatedAt: number
}

export type EncryptedBlob = {
  ciphertextB64: string
  ivB64: string
  aadB64: string
  schemaVersion: number
}

export type QuestionRecord = {
  id: string
  pairId: string
  createdBy: string
  createdAt: number
  blob: EncryptedBlob
}

export type AnswerRecord = {
  id: string
  questionId: string
  pairId: string
  userId: string
  createdAt: number
  blob: EncryptedBlob
}

export type DatabaseShape = {
  users: UserRecord[]
  pairs: PairRecord[]
  questions: QuestionRecord[]
  answers: AnswerRecord[]
}

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const baseDir = path.join(__dirname, '../../data')

export const dbStore = new FileStore<DatabaseShape>(baseDir, 'db.json', {
  users: [],
  pairs: [],
  questions: [],
  answers: [],
})

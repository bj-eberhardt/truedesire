import http from 'node:http'
import { URL } from 'node:url'
import { dbStore, type AnswerRecord, type PairRecord, type QuestionRecord } from './storage/db.js'
import { verifyRequestSignature } from './crypto/auth.js'
import { isoWeekKey } from './utils/week.js'
import { newId } from './crypto/auth.js'

type Json = any

function json(res: http.ServerResponse, status: number, body: Json) {
  const data = Buffer.from(JSON.stringify(body))
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': String(data.length),
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'content-type,x-user-id,x-timestamp,x-nonce,x-signature',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
  })
  res.end(data)
}

function text(res: http.ServerResponse, status: number, body: string) {
  const data = Buffer.from(body, 'utf8')
  res.writeHead(status, {
    'content-type': 'text/plain; charset=utf-8',
    'content-length': String(data.length),
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'content-type,x-user-id,x-timestamp,x-nonce,x-signature',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
  })
  res.end(data)
}

function bad(res: http.ServerResponse, code: string, status = 400) {
  return json(res, status, { error: code })
}

type NonceInfo = { expiresAt: number }
const seenNoncesByUser = new Map<string, Map<string, NonceInfo>>()

function pruneNonces(now: number) {
  for (const [userId, map] of seenNoncesByUser.entries()) {
    for (const [nonce, info] of map.entries()) {
      if (info.expiresAt <= now) map.delete(nonce)
    }
    if (map.size === 0) seenNoncesByUser.delete(userId)
  }
}

async function requireAuth(req: http.IncomingMessage, rawBody: Uint8Array): Promise<{ userId: string } | null> {
  const userId = String(req.headers['x-user-id'] ?? '')
  const timestamp = String(req.headers['x-timestamp'] ?? '')
  const nonce = String(req.headers['x-nonce'] ?? '')
  const signatureB64 = String(req.headers['x-signature'] ?? '')

  if (!userId || !timestamp || !nonce || !signatureB64) return null
  const ts = Number(timestamp)
  if (!Number.isFinite(ts)) return null

  const now = Date.now()
  const maxSkewMs = 5 * 60 * 1000
  if (Math.abs(now - ts) > maxSkewMs) return null

  pruneNonces(now)
  const ttlMs = 10 * 60 * 1000
  const perUser = seenNoncesByUser.get(userId) ?? new Map<string, NonceInfo>()
  if (perUser.has(nonce)) return null
  perUser.set(nonce, { expiresAt: now + ttlMs })
  seenNoncesByUser.set(userId, perUser)

  const db = dbStore.readSync()
  const user = db.users.find((u) => u.id === userId)
  if (!user) return null

  const url = new URL(req.url ?? '/', 'http://localhost')
  const ok = await verifyRequestSignature({
    signPublicJwk: user.signPublicJwk,
    method: req.method ?? 'GET',
    pathWithQuery: url.pathname + url.search,
    timestamp,
    nonce,
    rawBody,
    signatureB64,
  })
  if (!ok) return null
  return { userId }
}

async function readBody(req: http.IncomingMessage): Promise<{ raw: Buffer; json: any | null }> {
  const chunks: Buffer[] = []
  for await (const c of req) chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c))
  const raw = Buffer.concat(chunks)
  const ct = String(req.headers['content-type'] ?? '')
  if (!raw.length) return { raw, json: null }
  if (!ct.includes('application/json')) return { raw, json: null }
  try {
    return { raw, json: JSON.parse(raw.toString('utf8')) }
  } catch {
    return { raw, json: null }
  }
}

function requirePairMember(db: any, pairId: string, userId: string): PairRecord | null {
  const pair = db.pairs.find((p: PairRecord) => p.id === pairId)
  if (!pair) return null
  if (![pair.userA, pair.userB].includes(userId)) return null
  return pair
}

const server = http.createServer(async (req, res) => {
  if (!req.url) return bad(res, 'bad_request')

  if (req.method === 'OPTIONS') return text(res, 204, '')

  const url = new URL(req.url, 'http://localhost')
  const { raw, json: body } = await readBody(req)

  if (req.method === 'GET' && url.pathname === '/health') return json(res, 200, { ok: true })

  if (req.method === 'POST' && url.pathname === '/auth/register') {
    const nickname = typeof body?.nickname === 'string' ? body.nickname.slice(0, 40) : 'Anon'
    const signPublicJwk = body?.signPublicJwk as JsonWebKey | undefined
    const ecdhPublicRawB64 = body?.ecdhPublicRawB64 as string | undefined
    if (!signPublicJwk || !ecdhPublicRawB64) return bad(res, 'bad_request')
    if (typeof ecdhPublicRawB64 !== 'string' || ecdhPublicRawB64.length < 16) return bad(res, 'bad_ecdh_public')

    const db = dbStore.readSync()
    const userId = newId()
    db.users.push({ id: userId, nickname, signPublicJwk, ecdhPublicRawB64, createdAt: Date.now() })
    await dbStore.write(db)
    return json(res, 200, { userId })
  }

  const auth = await requireAuth(req, raw)
  if (!auth) return bad(res, 'unauthorized', 401)
  const userId = auth.userId

  if (req.method === 'GET' && url.pathname === '/auth/me') {
    const db = dbStore.readSync()
    const user = db.users.find((u) => u.id === userId)
    if (!user) return bad(res, 'not_found', 404)
    return json(res, 200, { id: user.id, nickname: user.nickname, ecdhPublicRawB64: user.ecdhPublicRawB64 })
  }

  if (req.method === 'POST' && url.pathname === '/pair/create') {
    const db = dbStore.readSync()
    const pairId = newId().slice(0, 8)
    const pair: PairRecord = {
      id: pairId,
      userA: userId,
      userB: null,
      confirmA: false,
      confirmB: false,
      status: 'pending',
      weeklyLimit: 5,
      weeklyLimitProposals: {},
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    db.pairs.push(pair)
    await dbStore.write(db)
    return json(res, 200, { pairId })
  }

  if (req.method === 'POST' && url.pathname === '/pair/join') {
    const pairId = String(body?.pairId ?? '')
    if (!pairId) return bad(res, 'bad_request')
    const db = dbStore.readSync()
    const pair = db.pairs.find((p) => p.id === pairId)
    if (!pair) return bad(res, 'not_found', 404)
    if (pair.userA === userId) return bad(res, 'cannot_join_own_pair', 400)
    if (pair.userB && pair.userB !== userId) return bad(res, 'pair_full', 409)
    pair.userB = userId
    pair.updatedAt = Date.now()
    await dbStore.write(db)
    return json(res, 200, { ok: true })
  }

  if (req.method === 'POST' && url.pathname === '/pair/confirm') {
    const pairId = String(body?.pairId ?? '')
    if (!pairId) return bad(res, 'bad_request')
    const db = dbStore.readSync()
    const pair = db.pairs.find((p) => p.id === pairId)
    if (!pair) return bad(res, 'not_found', 404)
    if (![pair.userA, pair.userB].includes(userId)) return bad(res, 'forbidden', 403)
    if (pair.userA === userId) pair.confirmA = true
    if (pair.userB === userId) pair.confirmB = true
    if (pair.userA && pair.userB && pair.confirmA && pair.confirmB) pair.status = 'active'
    pair.updatedAt = Date.now()
    await dbStore.write(db)
    return json(res, 200, { ok: true, status: pair.status })
  }

  if (req.method === 'POST' && url.pathname === '/pair/weekly-limit/propose') {
    const pairId = String(body?.pairId ?? '')
    const limit = Number(body?.limit)
    if (!pairId || !Number.isFinite(limit) || limit < 1 || limit > 50) return bad(res, 'bad_request')
    const db = dbStore.readSync()
    const pair = db.pairs.find((p) => p.id === pairId)
    if (!pair) return bad(res, 'not_found', 404)
    if (![pair.userA, pair.userB].includes(userId)) return bad(res, 'forbidden', 403)
    pair.weeklyLimitProposals[userId] = limit
    const a = pair.userA ? pair.weeklyLimitProposals[pair.userA] : undefined
    const b = pair.userB ? pair.weeklyLimitProposals[pair.userB] : undefined
    if (a && b && a === b) pair.weeklyLimit = a
    pair.updatedAt = Date.now()
    await dbStore.write(db)
    return json(res, 200, { ok: true, weeklyLimit: pair.weeklyLimit, proposals: pair.weeklyLimitProposals })
  }

  const pairMatch = url.pathname.match(/^\/pair\/([A-Za-z0-9_-]+)$/)
  if (req.method === 'GET' && pairMatch) {
    const pairId = pairMatch[1]
    const db = dbStore.readSync()
    const pair = db.pairs.find((p) => p.id === pairId)
    if (!pair) return bad(res, 'not_found', 404)
    if (![pair.userA, pair.userB].includes(userId)) return bad(res, 'forbidden', 403)
    const userA = db.users.find((u) => u.id === pair.userA)
    const userB = pair.userB ? db.users.find((u) => u.id === pair.userB) : null
    return json(res, 200, {
      id: pair.id,
      status: pair.status,
      weeklyLimit: pair.weeklyLimit,
      confirmA: pair.confirmA,
      confirmB: pair.confirmB,
      userA: userA ? { id: userA.id, nickname: userA.nickname, ecdhPublicRawB64: userA.ecdhPublicRawB64 } : null,
      userB: userB ? { id: userB.id, nickname: userB.nickname, ecdhPublicRawB64: userB.ecdhPublicRawB64 } : null,
    })
  }

  if (req.method === 'POST' && url.pathname === '/questions') {
    const pairId = String(body?.pairId ?? '')
    const blob = body?.blob as QuestionRecord['blob'] | undefined
    if (!pairId || !blob?.ciphertextB64 || !blob?.ivB64 || !blob?.aadB64) return bad(res, 'bad_request')
    const now = Date.now()
    const db = dbStore.readSync()
    const pair = requirePairMember(db, pairId, userId)
    if (!pair) return bad(res, 'forbidden', 403)
    if (pair.status !== 'active') return bad(res, 'pair_not_active', 409)
    const week = isoWeekKey(now)
    const createdThisWeek = db.questions.filter((q) => q.pairId === pairId && isoWeekKey(q.createdAt) === week).length
    if (createdThisWeek >= pair.weeklyLimit) return bad(res, 'weekly_limit_reached', 429)

    const q: QuestionRecord = { id: newId(), pairId, createdBy: userId, createdAt: now, blob: { ...blob, schemaVersion: 1 } }
    db.questions.push(q)
    await dbStore.write(db)
    return json(res, 200, q)
  }

  const questionsMatch = url.pathname.match(/^\/questions\/([A-Za-z0-9_-]+)$/)
  if (req.method === 'GET' && questionsMatch) {
    const pairId = questionsMatch[1]
    const db = dbStore.readSync()
    const pair = requirePairMember(db, pairId, userId)
    if (!pair) return bad(res, 'forbidden', 403)
    return json(res, 200, db.questions.filter((q) => q.pairId === pairId))
  }

  if (req.method === 'POST' && url.pathname === '/answers') {
    const questionId = String(body?.questionId ?? '')
    const blob = body?.blob as AnswerRecord['blob'] | undefined
    if (!questionId || !blob?.ciphertextB64 || !blob?.ivB64 || !blob?.aadB64) return bad(res, 'bad_request')
    const now = Date.now()
    const db = dbStore.readSync()
    const question = db.questions.find((q) => q.id === questionId)
    if (!question) return bad(res, 'not_found', 404)
    const pair = requirePairMember(db, question.pairId, userId)
    if (!pair) return bad(res, 'forbidden', 403)
    if (pair.status !== 'active') return bad(res, 'pair_not_active', 409)

    const already = db.answers.find((a) => a.questionId === questionId && a.userId === userId)
    if (already) return bad(res, 'already_answered', 409)

    const week = isoWeekKey(now)
    const answeredThisWeek = db.answers.filter((a) => a.pairId === pair.id && a.userId === userId && isoWeekKey(a.createdAt) === week).length
    if (answeredThisWeek >= pair.weeklyLimit) return bad(res, 'weekly_limit_reached', 429)

    const answer: AnswerRecord = { id: newId(), questionId, pairId: pair.id, userId, createdAt: now, blob: { ...blob, schemaVersion: 1 } }
    db.answers.push(answer)
    await dbStore.write(db)
    return json(res, 200, answer)
  }

  const answersMatch = url.pathname.match(/^\/answers\/([A-Za-z0-9_-]+)$/)
  if (req.method === 'GET' && answersMatch) {
    const questionId = answersMatch[1]
    const db = dbStore.readSync()
    const question = db.questions.find((q) => q.id === questionId)
    if (!question) return bad(res, 'not_found', 404)
    const pair = requirePairMember(db, question.pairId, userId)
    if (!pair) return bad(res, 'forbidden', 403)
    return json(res, 200, db.answers.filter((a) => a.questionId === questionId))
  }

  return bad(res, 'not_found', 404)
})

const port = Number(process.env.PORT ?? 3001)
server.listen(port, () => console.log(`Server listening on http://localhost:${port}`))

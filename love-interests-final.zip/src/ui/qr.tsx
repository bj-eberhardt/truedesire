import { useEffect, useRef, useState } from 'react'
import { QrCode, QrCodeEcc } from '../vendor/qrcodegen'

export function QrInvite(props: { value: string }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const qr = QrCode.encodeText(props.value, QrCodeEcc.MEDIUM)
    const border = 2
    const scale = Math.floor(canvas.width / (qr.size + border * 2))
    const size = (qr.size + border * 2) * scale
    canvas.width = size
    canvas.height = size

    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, size, size)
    ctx.fillStyle = '#0b0f16'
    for (let y = 0; y < qr.size; y++) {
      for (let x = 0; x < qr.size; x++) {
        if (qr.getModule(x, y)) {
          ctx.fillRect((x + border) * scale, (y + border) * scale, scale, scale)
        }
      }
    }
  }, [props.value])

  return (
    <div className="qr">
      <canvas ref={canvasRef} width={240} height={240} />
      <div className="row">
        <button
          className="secondary"
          onClick={async () => {
            await navigator.clipboard.writeText(props.value)
            alert('Pairing-Daten kopiert.')
          }}
        >
          Kopieren
        </button>
      </div>
    </div>
  )
}

export function QrScanner(props: { onValue: (text: string) => void }) {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const [status, setStatus] = useState<string>('Starte Kamera…')

  useEffect(() => {
    let stopped = false
    let stream: MediaStream | null = null
    let raf = 0

    async function start() {
      try {
        if (!('BarcodeDetector' in window)) {
          setStatus('QR-Scan nicht unterstützt (BarcodeDetector fehlt).')
          return
        }
        const detector = new (window as any).BarcodeDetector({ formats: ['qr_code'] })
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
        if (stopped) return
        const video = videoRef.current
        if (!video) return
        video.srcObject = stream
        await video.play()
        setStatus('Suche QR…')

        const tick = async () => {
          if (stopped) return
          try {
            const barcodes = await detector.detect(video)
            if (barcodes?.length) {
              const raw = barcodes[0].rawValue
              if (raw) props.onValue(String(raw))
            }
          } catch {
            // ignore
          }
          raf = requestAnimationFrame(tick)
        }
        raf = requestAnimationFrame(tick)
      } catch (e: any) {
        setStatus(e?.message ?? 'Kamera-Start fehlgeschlagen.')
      }
    }

    start()
    return () => {
      stopped = true
      cancelAnimationFrame(raf)
      if (stream) stream.getTracks().forEach((t) => t.stop())
    }
  }, [props])

  return (
    <div className="qr-scan">
      <video ref={videoRef} className="video" muted playsInline />
      <div className="hint">{status}</div>
    </div>
  )
}

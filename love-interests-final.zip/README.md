# love.interests

Privacy-first “Fragen-Spiel” für Paare:

- Zwei Geräte beantworten dieselben Fragen (Ja/Nein/Vielleicht)
- Ende-zu-Ende verschlüsselte Speicherung (Server sieht nur Ciphertext)
- Pairing via QR-Code (oder manuell via Pair-ID)
- Auswertung: nur Optionen ohne „Nein“ werden als Match gezeigt
- Wochenlimit pro Pair (nur aktiv, wenn beide zustimmen)

## Start (Dev)

1) Server (Node.js + TypeScript, ohne externe Dependencies):

```bash
npm run server:build
npm run server:start
```

Server läuft standardmäßig auf `http://localhost:3001` und speichert Daten in `server/data/db.json`.

2) Client (Vite):

```bash
npm install
npm run dev
```

Optional: `VITE_API_BASE` setzen (z.B. in `.env.local`):

```bash
VITE_API_BASE=http://localhost:3001
```

## Sicherheit (Kurzüberblick)

- API-Requests sind signiert (ECDSA P‑256). Der Server akzeptiert nur Requests mit gültiger Signatur für die gespeicherte `signPublicJwk` des Users.
- Inhalte (Fragen/Antworten) sind AES‑GCM verschlüsselt. Der Schlüssel wird per ECDH + HKDF aus den Geräte-Keys beider Partner abgeleitet.
- Backup/Restore: Private Keys bleiben auf dem Gerät (IndexedDB). Export/Import ist im UI verfügbar.
